from input_parser import InputParser
if __name__ == '__main__':
    input_parser = InputParser()
    input_parser.request_input()

